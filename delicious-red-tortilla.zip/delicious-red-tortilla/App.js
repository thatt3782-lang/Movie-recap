import React, { useState, useEffect } from 'react';
import {
  StyleSheet, Text, View, TouchableOpacity, ScrollView, SafeAreaView, 
  StatusBar, Image, TextInput, Platform, Alert, ActivityIndicator
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

// Initial Dialogues Data
const INITIAL_DIALOGUES = [
  { id: '1', timestamp: '00:01:15', speaker: 'Character (Male)', text: 'မင်း ငါ့ကို ဘာလို့ လာရှာတာလဲ။' },
  { id: '2', timestamp: '00:01:21', speaker: 'Narrator', text: 'သူမသည် တုံ့ဆိုင်းမနေဘဲ တိတ်ဆိတ်စွာပင် တံခါးကို ပိတ်လိုက်သည်။' },
  { id: '3', timestamp: '00:01:29', speaker: 'Character (Female)', text: 'ဒီကိစ္စ အားလုံးကို အပြီးသတ်ဖို့ ရောက်လာတာပါ။' },
];

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('Home');
  const [activeTab, setActiveTab] = useState('Projects');
  const [selectedVideo, setSelectedVideo] = useState(null);
  
  // Editor States
  const [dialogues, setDialogues] = useState(INITIAL_DIALOGUES);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(12); // seconds
  const [selectedSpeaker, setSelectedSpeaker] = useState('Character (Male)');
  
  // Audio & Export States
  const [aiVoice, setAiVoice] = useState('Burmese - Natural Male');
  const [exportQuality, setExportQuality] = useState('1080p');
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);

  const goHome = () => setCurrentScreen('Home');

  // Video Selection
  const handleSelectVideo = () => {
    setSelectedVideo("Sample_Scene_01.mp4");
    setCurrentScreen('ScriptEdit');
  };

  // Dialogue Controls
  const handleAddDialogue = () => {
    const newId = (dialogues.length + 1).toString();
    const newEntry = {
      id: newId,
      timestamp: `00:01:${currentTime < 10 ? '0' + currentTime : currentTime}`,
      speaker: selectedSpeaker,
      text: ''
    };
    setDialogues([...dialogues, newEntry]);
  };

  const handleDeleteDialogue = (id) => {
    setDialogues(dialogues.filter(item => item.id !== id));
  };

  const handleTextChange = (id, newText) => {
    setDialogues(dialogues.map(item => item.id === id ? { ...item, text: newText } : item));
  };

  // Export Simulation
  const startExport = () => {
    setIsExporting(true);
    setExportProgress(0);
    let interval = setInterval(() => {
      setExportProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsExporting(false);
          Alert.alert("Success", "Video Exported Successfully!");
          return 100;
        }
        return prev + 20;
      });
    }, 500);
  };

  // --- SCREENS ---

  // 1. HOME SCREEN
  const HomeScreen = () => (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0B101D" translucent={true} />
      
      <View style={styles.header}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <View style={styles.avatarWrapper}>
            <Image source={{uri: 'https://i.postimg.cc/m2y17dTF/a18d44c0-991c-11f1-836e-afbd8a8d4790.webp'}} style={styles.avatar} />
          </View>
          <Text style={styles.headerTitle}>PTL Studio</Text>
        </View>
        <TouchableOpacity style={styles.iconBtn}>
          <Ionicons name="notifications-outline" size={22} color="#FFF" />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{paddingBottom: 100}}>
        {/* Navigation Tabs */}
        <View style={styles.tabContainer}>
          {['Projects', 'Scripts', 'Audio', 'Settings'].map((tab) => (
            <TouchableOpacity 
              key={tab} 
              style={[styles.tab, activeTab === tab && styles.activeTab]}
              onPress={() => setActiveTab(tab)}
            >
              <Text style={[styles.tabText, activeTab === tab && {color: '#0B101D'}]}>{tab}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* New Video Button */}
        <TouchableOpacity style={styles.newVideoBtn} onPress={() => setCurrentScreen('ImportVideo')}>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Ionicons name="add-circle" size={28} color="#0B101D" />
            <Text style={styles.newVideoText}>New Project / Import Video</Text>
          </View>
          <Ionicons name="chevron-forward" size={20} color="#0B101D" />
        </TouchableOpacity>

        {/* Recent Projects */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Recent Projects</Text>
          <TouchableOpacity><Text style={{color: '#D4AF37', fontSize: 12}}>View all</Text></TouchableOpacity>
        </View>

        {[
          {title: 'Mountain Awakening', date: 'May 16, 2026 | 1080p', time: '04:32'},
          {title: 'Moonlit Journey', date: 'May 12, 2026 | 4K', time: '03:18'},
        ].map((item, index) => (
          <TouchableOpacity key={index} style={styles.projectCard} onPress={() => setCurrentScreen('ScriptEdit')}>
            <View style={styles.thumbnail}>
              <Ionicons name="play" size={16} color="#FFF" />
              <Text style={{color:'#FFF', fontSize: 10, marginLeft: 4}}>{item.time}</Text>
            </View>
            <View style={{flex: 1, marginLeft: 12}}>
              <Text style={styles.projectTitle}>{item.title}</Text>
              <Text style={{color: '#8E9BAE', fontSize: 11, marginTop: 2}}>{item.date}</Text>
            </View>
            <Ionicons name="ellipsis-vertical" size={18} color="#8E9BAE" />
          </TouchableOpacity>
        ))}

        {/* Quick Actions */}
        <Text style={[styles.sectionTitle, {paddingHorizontal: 16, marginTop: 16, marginBottom: 10}]}>Quick Tools</Text>
        <View style={styles.quickActionsGrid}>
          {[
            {icon: 'mic-outline', label: 'AI Voiceover', screen: 'AudioSettings'},
            {icon: 'download-outline', label: 'Export Video', screen: 'Export'},
          ].map((action, i) => (
            <TouchableOpacity key={i} style={styles.actionCard} onPress={() => setCurrentScreen(action.screen)}>
              <Ionicons name={action.icon} size={22} color="#D4AF37" />
              <Text style={styles.actionText}>{action.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );

  // 2. IMPORT VIDEO SCREEN
  const ImportVideoScreen = () => (
    <SafeAreaView style={styles.container}>
      <View style={styles.navHeader}>
        <TouchableOpacity onPress={goHome}><Ionicons name="arrow-back" size={24} color="#D4AF37" /></TouchableOpacity>
        <Text style={styles.navTitle}>Import Media</Text>
      </View>
      <View style={{padding: 20, flex: 1, justifyContent: 'center'}}>
        <View style={styles.uploadBox}>
          <Ionicons name="cloud-upload-outline" size={50} color="#D4AF37" />
          <Text style={{color: '#FFF', fontSize: 16, marginTop: 12, fontWeight: 'bold'}}>Select Video File</Text>
          <Text style={{color: '#8E9BAE', fontSize: 12, marginTop: 4}}>Supports MP4, MOV, MKV</Text>
          <TouchableOpacity style={[styles.primaryBtn, {marginTop: 20}]} onPress={handleSelectVideo}>
            <Text style={styles.primaryBtnText}>Browse Gallery</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );

  // 3. SCRIPT & VIDEO EDITOR SCREEN
  const ScriptEditScreen = () => (
    <SafeAreaView style={styles.container}>
      <View style={styles.navHeader}>
        <TouchableOpacity onPress={goHome}><Ionicons name="arrow-back" size={24} color="#D4AF37" /></TouchableOpacity>
        <Text style={styles.navTitle}>Video & Script Editor</Text>
        <TouchableOpacity style={{marginLeft: 'auto'}} onPress={() => setCurrentScreen('AudioSettings')}>
          <Ionicons name="settings-outline" size={22} color="#D4AF37" />
        </TouchableOpacity>
      </View>

      <ScrollView style={{flex: 1}} contentContainerStyle={{paddingBottom: 40}}>
        {/* Video Player Preview Area */}
        <View style={styles.playerContainer}>
          <View style={styles.videoPlaceholder}>
            <Ionicons name="videocam-outline" size={40} color="#8E9BAE" />
            <Text style={{color: '#FFF', marginTop: 8, fontSize: 12}}>
              {selectedVideo || "Sample_Video_Preview.mp4"}
            </Text>
            {/* Live Subtitle Overlay */}
            <View style={styles.subtitleOverlay}>
              <Text style={styles.subtitleText}>
                {dialogues[0]?.text || "Subtitle preview will appear here..."}
              </Text>
            </View>
          </View>

          {/* Player Controls */}
          <View style={styles.playerControls}>
            <TouchableOpacity onPress={() => setCurrentTime(Math.max(0, currentTime - 5))}>
              <Ionicons name="play-back" size={20} color="#FFF" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.playBtn} onPress={() => setIsPlaying(!isPlaying)}>
              <Ionicons name={isPlaying ? "pause" : "play"} size={22} color="#0B101D" />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setCurrentTime(currentTime + 5)}>
              <Ionicons name="play-forward" size={20} color="#FFF" />
            </TouchableOpacity>
            <Text style={{color: '#D4AF37', marginLeft: 'auto', fontSize: 12}}>00:01:{currentTime < 10 ? '0'+currentTime : currentTime}</Text>
          </View>
        </View>

        {/* Script Section */}
        <View style={{padding: 16}}>
          <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12}}>
            <Text style={styles.sectionTitle}>Dialogues & Subtitles</Text>
            <TouchableOpacity style={styles.addBtn} onPress={handleAddDialogue}>
              <Ionicons name="add" size={16} color="#0B101D" />
              <Text style={{color: '#0B101D', fontWeight: 'bold', fontSize: 12, marginLeft: 4}}>Add Line</Text>
            </TouchableOpacity>
          </View>

          {dialogues.map((item) => (
            <View key={item.id} style={styles.dialogueCard}>
              <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'}}>
                <Text style={styles.timestampText}>⏱ {item.timestamp}</Text>
                <Text style={styles.speakerBadge}>{item.speaker}</Text>
                <TouchableOpacity onPress={() => handleDeleteDialogue(item.id)}>
                  <Ionicons name="trash-outline" size={18} color="#FF5252" />
                </TouchableOpacity>
              </View>
              <TextInput
                style={styles.scriptInput}
                value={item.text}
                onChangeText={(text) => handleTextChange(item.id, text)}
                placeholder="Enter Myanmar dialogue here..."
                placeholderTextColor="#8E9BAE"
                multiline
              />
            </View>
          ))}
        </View>
      </ScrollView>

      {/* Bottom Export Bar */}
      <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.primaryBtn} onPress={() => setCurrentScreen('Export')}>
          <Text style={styles.primaryBtnText}>Proceed to Export</Text>
          <Ionicons name="arrow-forward" size={18} color="#0B101D" style={{marginLeft: 6}} />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );

  // 4. AUDIO & VOICE SETTINGS SCREEN
  const AudioSettingsScreen = () => (
    <SafeAreaView style={styles.container}>
      <View style={styles.navHeader}>
        <TouchableOpacity onPress={() => setCurrentScreen('ScriptEdit')}><Ionicons name="arrow-back" size={24} color="#D4AF37" /></TouchableOpacity>
        <Text style={styles.navTitle}>AI Voice & Audio</Text>
      </View>
      <View style={{padding: 16}}>
        <Text style={styles.label}>Select AI Voice Profile</Text>
        {['Burmese - Natural Male', 'Burmese - Soft Female', 'Narrator (Deep Male)'].map((voice) => (
          <TouchableOpacity 
            key={voice} 
            style={[styles.optionCard, aiVoice === voice && styles.selectedOption]}
            onPress={() => setAiVoice(voice)}
          >
            <Text style={{color: '#FFF', fontWeight: 'bold'}}>{voice}</Text>
            {aiVoice === voice && <Ionicons name="checkmark-circle" size={20} color="#D4AF37" />}
          </TouchableOpacity>
        ))}

        <TouchableOpacity style={[styles.primaryBtn, {marginTop: 30}]} onPress={() => setCurrentScreen('ScriptEdit')}>
          <Text style={styles.primaryBtnText}>Save Settings</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );

  // 5. EXPORT SCREEN
  const ExportScreen = () => (
    <SafeAreaView style={styles.container}>
      <View style={styles.navHeader}>
        <TouchableOpacity onPress={() => setCurrentScreen('ScriptEdit')}><Ionicons name="arrow-back" size={24} color="#D4AF37" /></TouchableOpacity>
        <Text style={styles.navTitle}>Export Video</Text>
      </View>
      <View style={{padding: 20, flex: 1, justifyContent: 'center'}}>
        <Text style={styles.label}>Select Resolution</Text>
        <View style={{flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20}}>
          {['720p', '1080p', '4K'].map((res) => (
            <TouchableOpacity 
              key={res} 
              style={[styles.resBtn, exportQuality === res && styles.activeResBtn]}
              onPress={() => setExportQuality(res)}
            >
              <Text style={{color: exportQuality === res ? '#0B101D' : '#FFF', fontWeight: 'bold'}}>{res}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {isExporting ? (
          <View style={{alignItems: 'center', marginVertical: 20}}>
            <ActivityIndicator size="large" color="#D4AF37" />
            <Text style={{color: '#FFF', marginTop: 12, fontSize: 16}}>Rendering Video... {exportProgress}%</Text>
          </View>
        ) : (
          <TouchableOpacity style={styles.primaryBtn} onPress={startExport}>
            <Ionicons name="download" size={20} color="#0B101D" style={{marginRight: 8}} />
            <Text style={styles.primaryBtnText}>Start Export ({exportQuality})</Text>
          </TouchableOpacity>
        )}
      </View>
    </SafeAreaView>
  );

  // Router
  if (currentScreen === 'Home') return <HomeScreen />;
  if (currentScreen === 'ImportVideo') return <ImportVideoScreen />;
  if (currentScreen === 'ScriptEdit') return <ScriptEditScreen />;
  if (currentScreen === 'AudioSettings') return <AudioSettingsScreen />;
  return <ExportScreen />;
}

// STYLES
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B101D' },
  header: { 
    flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 16, 
    paddingBottom: 12, paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight || 24) + 12 : 40, 
    alignItems: 'center', backgroundColor: '#0B101D' 
  },
  avatarWrapper: { width: 36, height: 36, borderRadius: 18, overflow: 'hidden', marginRight: 10, backgroundColor: '#161F33' },
  avatar: { width: '100%', height: '100%' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#D4AF37' },
  iconBtn: { padding: 4 },
  
  tabContainer: { flexDirection: 'row', paddingHorizontal: 16, marginVertical: 12, justifyContent: 'space-between' },
  tab: { paddingVertical: 6, paddingHorizontal: 12, borderRadius: 16, backgroundColor: '#161F33' },
  activeTab: { backgroundColor: '#D4AF37' },
  tabText: { color: '#8E9BAE', fontSize: 12, fontWeight: 'bold' },
  
  newVideoBtn: { backgroundColor: '#D4AF37', marginHorizontal: 16, marginBottom: 16, padding: 14, borderRadius: 12, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  newVideoText: { fontSize: 14, fontWeight: 'bold', color: '#0B101D', marginLeft: 8 },
  
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 16, marginBottom: 10, alignItems: 'center' },
  sectionTitle: { color: '#FFF', fontSize: 15, fontWeight: 'bold' },
  projectCard: { flexDirection: 'row', padding: 10, marginHorizontal: 16, marginBottom: 8, backgroundColor: '#161F33', borderRadius: 10, alignItems: 'center' },
  thumbnail: { width: 60, height: 40, backgroundColor: '#000', borderRadius: 6, justifyContent: 'center', alignItems: 'center', flexDirection: 'row' },
  projectTitle: { color: '#FFF', fontWeight: 'bold', fontSize: 13 },
  
  quickActionsGrid: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 16 },
  actionCard: { width: '48%', backgroundColor: '#161F33', padding: 14, borderRadius: 10, alignItems: 'center' },
  actionText: { color: '#FFF', fontSize: 12, marginTop: 6, fontWeight: '500' },
  
  navHeader: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingBottom: 12, paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight || 24) + 12 : 40 },
  navTitle: { color: '#FFF', fontSize: 16, fontWeight: 'bold', marginLeft: 12 },
  
  uploadBox: { backgroundColor: '#161F33', padding: 30, borderRadius: 16, alignItems: 'center', borderWidth: 1, borderColor: '#2A3854', borderStyle: 'dashed' },
  primaryBtn: { backgroundColor: '#D4AF37', paddingVertical: 12, paddingHorizontal: 20, borderRadius: 10, alignItems: 'center', flexDirection: 'row', justifyContent: 'center' },
  primaryBtnText: { color: '#0B101D', fontWeight: 'bold', fontSize: 14 },
  
  // Editor Styles
  playerContainer: { backgroundColor: '#161F33', margin: 16, borderRadius: 12, overflow: 'hidden' },
  videoPlaceholder: { height: 180, backgroundColor: '#000', justifyContent: 'center', alignItems: 'center', position: 'relative' },
  subtitleOverlay: { position: 'absolute', bottom: 10, backgroundColor: 'rgba(0,0,0,0.75)', paddingHorizontal: 12, paddingVertical: 4, borderRadius: 4 },
  subtitleText: { color: '#FFF', fontSize: 12, fontWeight: 'bold' },
  playerControls: { flexDirection: 'row', alignItems: 'center', padding: 12, backgroundColor: '#161F33' },
  playBtn: { backgroundColor: '#D4AF37', width: 36, height: 36, borderRadius: 18, justifyContent: 'center', alignItems: 'center', marginHorizontal: 16 },
  
  addBtn: { backgroundColor: '#D4AF37', flexDirection: 'row', alignItems: 'center', paddingVertical: 4, paddingHorizontal: 8, borderRadius: 6 },
  dialogueCard: { backgroundColor: '#161F33', padding: 12, borderRadius: 8, marginBottom: 10 },
  timestampText: { color: '#D4AF37', fontSize: 11, fontWeight: 'bold' },
  speakerBadge: { color: '#8E9BAE', fontSize: 10, backgroundColor: '#0B101D', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
  scriptInput: { color: '#FFF', padding: 8, backgroundColor: '#0B101D', marginTop: 8, borderRadius: 6, fontSize: 13 },
  bottomBar: { padding: 16, backgroundColor: '#161F33', borderTopWidth: 1, borderColor: '#2A3854' },
  
  label: { color: '#FFF', fontSize: 14, fontWeight: 'bold', marginBottom: 12 },
  optionCard: { backgroundColor: '#161F33', padding: 14, borderRadius: 8, flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  selectedOption: { borderWidth: 1, borderColor: '#D4AF37' },
  resBtn: { width: '30%', backgroundColor: '#161F33', padding: 12, borderRadius: 8, alignItems: 'center' },
  activeResBtn: { backgroundColor: '#D4AF37' }
});
